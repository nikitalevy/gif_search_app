import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/models/gif_model.dart';
import '../../../data/repository/gif_repository.dart';

// состояние поиска
class SearchState {
  final List<GifModel> items;
  final bool isLoading;
  final String? error;
  final String query;

  SearchState({
    this.items = const [],
    this.isLoading = false,
    this.error,
    this.query = '',
  });

  SearchState copyWith({
    List<GifModel>? items,
    bool? isLoading,
    String? error,
    String? query,
  }) {
    return SearchState(
      items: items ?? this.items,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      query: query ?? this.query,
    );
  }
}

class SearchNotifier extends StateNotifier<SearchState> {
  final GifRepository repository;
  final ScrollController scrollController = ScrollController();

  Timer? _debounce;
  static const _limit = 25;

  SearchNotifier(this.repository) : super(SearchState()) {
    scrollController.addListener(() {
      if (scrollController.position.pixels >=
          scrollController.position.maxScrollExtent - 200) {
        loadMore();
      }
    });
  }

  void onQueryChanged(String query) {
    state = state.copyWith(query: query);
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      search(query);
    });
  }

  Future<void> search(String query) async {
    if (query.isEmpty) {
      state = SearchState(query: '');
      return;
    }
    state = state.copyWith(isLoading: true, error: null, items: []);
    final offset = 0;

    try {
      final items = await repository.search(
        query: query,
        limit: _limit,
        offset: offset,
      );
      state = state.copyWith(items: items, isLoading: false, error: null);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: 'Failed to load GIFs');
    }
  }

  Future<void> loadMore() async {
    if (state.isLoading || state.query.isEmpty) return;
    state = state.copyWith(isLoading: true);

    try {
      final more = await repository.search(
        query: state.query,
        limit: _limit,
        offset: state.items.length, // берём текущее количество
      );

      if (more.isNotEmpty) {
        state = state.copyWith(
          items: [...state.items, ...more],
          isLoading: false,
          error: null,
        );
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (_) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to load more GIFs',
      );
    }
  }


  @override
  void dispose() {
    scrollController.dispose();
    _debounce?.cancel();
    super.dispose();
  }
}

final searchNotifierProvider =
StateNotifierProvider<SearchNotifier, SearchState>((ref) {
  final repo = ref.read(gifRepositoryProvider);
  return SearchNotifier(repo);
});
