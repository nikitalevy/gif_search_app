class AppConfig {
  static const String giphyApiKey = "0uuR1580UHlD18idiaXDvswoWhKXZPjs";
  static const String giphyBaseUrl = "https://api.giphy.com/v1/gifs";
}


