class GifModel {
  final String id;
  final String title;
  final String previewUrl;
  final String detailUrl;

  GifModel({
    required this.id,
    required this.title,
    required this.previewUrl,
    required this.detailUrl,
  });

  factory GifModel.fromJson(Map<String, dynamic> json) {
    final images = (json['images'] ?? {}) as Map<String, dynamic>;

    String? _pick(Map<String, dynamic>? data) {
      if (data == null) return null;
      return (data['url'] ?? data['webp'] ?? data['gif']) as String?;
    }

    return GifModel(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      previewUrl: _pick(images['fixed_height_small']) ??
          _pick(images['fixed_width']) ??
          '',
      detailUrl: _pick(images['original']) ?? '',
    );
  }
}
